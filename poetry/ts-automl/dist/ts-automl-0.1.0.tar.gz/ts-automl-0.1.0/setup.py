# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ts_automl']

package_data = \
{'': ['*']}

install_requires = \
['keras-tcn>=3.4.0,<4.0.0',
 'keras>=2.4.3,<3.0.0',
 'lightgbm>=3.2.1,<4.0.0',
 'pandas>=1.2.4,<2.0.0',
 'plotly>=4.14.3,<5.0.0',
 'skits>=0.1.2,<0.2.0',
 'sklearn>=0.0,<0.1',
 'statsmodels>=0.12.2,<0.13.0']

setup_kwargs = {
    'name': 'ts-automl',
    'version': '0.1.0',
    'description': 'An AutoML library for time series forecasting',
    'long_description': '### A python module for automated time series forecasting tasks.',
    'author': 'Miguel Murillo',
    'author_email': 'mmurillo@cic.es',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://gitlab.corp.cic.es/CIC/IDbox/idbox-ml-i-d/ts-automl',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
