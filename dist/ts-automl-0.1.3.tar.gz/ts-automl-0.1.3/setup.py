# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ts_automl']

package_data = \
{'': ['*'], 'ts_automl': ['.vscode/*']}

install_requires = \
['fastapi>=0.65.1,<0.66.0',
 'hpsklearn>=0.1.0,<0.2.0',
 'keras-tcn>=3.4.0,<4.0.0',
 'keras==2.4.3',
 'lightgbm>=3.2.1,<4.0.0',
 'pandas>=1.2.4,<2.0.0',
 'plotly>=4.14.3,<5.0.0',
 'python-multipart>=0.0.5,<0.0.6',
 'scikit-learn>=0.24.2,<0.25.0',
 'skits>=0.1.2,<0.2.0',
 'sktime>=0.6.0,<0.7.0',
 'statsmodels>=0.12.2,<0.13.0',
 'tensorflow==2.4.1']

setup_kwargs = {
    'name': 'ts-automl',
    'version': '0.1.3',
    'description': 'An AutoML library for time series forecasting',
    'long_description': '# ts-automl\n\n### An automated machine learning library for time series forecasting in python\n\n[![codecov](https://codecov.io/gh/MMurilloGlez/ts-automl/branch/master/graph/badge.svg?token=N85DT683O3)](https://codecov.io/gh/MMurilloGlez/ts-automl)   [![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2FMMurilloGlez%2Fts-automl.svg?type=shield)](https://app.fossa.com/projects/git%2Bgithub.com%2FMMurilloGlez%2Fts-automl?ref=badge_shield)\n\n## Installation\n\nCreate a python 3.8 virtual environment into which to install the library\n\n```python\nconda create -n ts_automl_test python=3.8\n```\n\nclone the github branch to download the installation files\n\n```\ngit clone https://github.com/MMurilloGlez/ts-automl.git ts-automl\n```\nactivate your environment and install wheel\n\n```python\nconda activate ts_automl_test\npip install wheel\n```\ninstall the library using pip install\n\n```python\npip install \'./ts-automl/dist/ts_automl-0.1.0-py3-none-any.whl\'\n```\ninstallation will take a while depending on the number of dependencies already on your system\n\n\n\n## Usage\n\nimport the prediction models and execute the scripts (changing anything needed for the particular series)\n\n\n* for slow prediction (LSTM + LightGBM + KNN):\n```python\nfrom ts_automl.pipelines import slow_prediction\nslow_prediction(filename=\'./example.csv\', \n\t\tfreq=\'15T\', \n                targetcol=\'TARGET\', \n                datecol=\'DATES\', \n                sep=\',\', \n                decimal=\'.\', \n                date_format="%d/%m/%Y %H:%M")\n```\n\n* for balanced prediction (LightGBM + KNN):\n```python\nfrom ts_automl.pipelines import balanced_prediction\nbalanced_prediction(filename=\'./example.csv\', \n\t\t    freq=\'15T\', \n            \t    targetcol=\'TARGET\', \n            \t    datecol=\'DATES\', \n            \t    sep=\',\', \n                    decimal=\'.\', \n            \t    date_format="%d/%m/%Y %H:%M")\n```\n\n* for fast prediction (KNN Model):\n```python\nfrom ts_automl.pipelines import fast_prediction\nfast_prediction(filename=\'./example.csv\', \n\t\tfreq=\'15T\', \n                targetcol=\'TARGET\', \n                datecol=\'DATES\', \n                sep=\',\', \n                decimal=\'.\', \n                date_format="%d/%m/%Y %H:%M")\n```\n\n* for naïve prediction (mean of last 50 values) (not recommended except for comparison with other models): \n```python\nfrom ts_automl.pipelines import naive_prediction\nnaive_prediction(filename=\'./example.csv\', \n\t\tfreq=\'15T\', \n                targetcol=\'TARGET\', \n                datecol=\'DATES\', \n                sep=\',\', \n                decimal=\'.\', \n                date_format="%d/%m/%Y %H:%M")\n```\n\n## Optional parameters\n\n* for fast, balanced and slow prediction:\n```python\npoints: int \n        Size of the horizon to predict in the future\nwindow_length: int\n        Number of points in the past to obtain lags for\nrolling_window: list of int\n        rolling window size to calculate the features\nselected_feat: int\n        Number of features to retain in feature selection.\nnum_datapoints: int\n        Size of the training set for the models\nplot: bool\n        Whether to plot or not the results\nerror: list of str [\'mape\',\'mse\',\'r2\', \'exp_var\']\n        Error metrics to calculate with respect to the test data \nrel_error: bool\n        Whether or not to calculate the error relative to naive forecast\n\n```\n\n\n* for naïve prediction:\n\n```python\npoints: int \n        Size of the horizon to predict in the future\nnum_datapoints: int\n        Size of the training set for the models\nplot: bool\n        Whether to plot or not the results\nerror: list of str [\'mape\',\'mse\',\'r2\', \'exp_var\']\n        Error metrics to calculate with respect to the test data \n```\n\n\n',
    'author': 'Miguel Murillo',
    'author_email': 'mmurillo@cic.es',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://gitlab.corp.cic.es/CIC/IDbox/idbox-ml-i-d/ts-automl',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
